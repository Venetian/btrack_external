*****************************************
*					*
*	btrack~ 			*
*	v 0.9				*
*					*
*	Centre for Digital Music	*
*	Queen Mary University of London	*
*	adam.stark@elec.qmul.ac.uk	*
*					*
*****************************************

1. Description

The Max/MSP object btrack~ is a real-time beat tracker taking as input an audio signal
and sending out a bang message at every beat.

2. Installation

- Place the btrack~.mxo object in your Max/MSP search path
- Place the btrack~.maxhelp patch in your Max/MSP search path

3. Usage

- Inlet: An audio signal, at 44.1kHz
- Outlet: A bang message on the beat


